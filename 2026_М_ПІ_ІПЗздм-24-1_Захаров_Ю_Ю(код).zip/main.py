import psycopg
import time
import statistics
import matplotlib.pyplot as plt

#Connection to DB
conn = psycopg.connect(
    "dbname=testdb user=postgres password=1568batman host=localhost port=5432"
)
cur = conn.cursor()

cur.execute("SET jit = off;")
conn.commit()

#Base parameters
SIZES = [100000, 200000, 300000, 500000, 700000, 1000000]

REPEATS = 30
WARMUP = 5

indexes = {
    "btree":      "CREATE INDEX idx_btree ON order_items(value1);",
    "hash":       "CREATE INDEX idx_hash ON order_items USING hash(value1);",
    "composite":  "CREATE INDEX idx_composite ON order_items(value1, value2);",
    "covering":   "CREATE INDEX idx_covering ON order_items(value1) INCLUDE(value2);",
    "partial":    "CREATE INDEX idx_partial ON orders(id) WHERE is_active = TRUE;",
    "brin":       "CREATE INDEX idx_brin ON order_items USING brin(value1);"
}

#DB Creation
def recreate_schema(n_rows):

    cur.execute("""
        DROP TABLE IF EXISTS order_items;
        DROP TABLE IF EXISTS orders;
        DROP TABLE IF EXISTS products;
        DROP TABLE IF EXISTS categories;
        DROP TABLE IF EXISTS addresses;
        DROP TABLE IF EXISTS customers;
    """)

    cur.execute("""
        CREATE TABLE customers (
            id SERIAL PRIMARY KEY,
            country TEXT,
            age INT
        );

        CREATE TABLE addresses (
            id SERIAL PRIMARY KEY,
            customer_id INT REFERENCES customers(id),
            city TEXT
        );

        CREATE TABLE categories (
            id SERIAL PRIMARY KEY,
            name TEXT
        );

        CREATE TABLE products (
            id SERIAL PRIMARY KEY,
            category_id INT REFERENCES categories(id),
            price NUMERIC
        );

        CREATE TABLE orders (
            id SERIAL PRIMARY KEY,
            customer_id INT REFERENCES customers(id),
            created_at DATE,
            is_active BOOLEAN
        );

        CREATE TABLE order_items (
            id SERIAL PRIMARY KEY,
            order_id INT REFERENCES orders(id),
            product_id INT REFERENCES products(id),
            value1 INT,
            value2 INT
        );
    """)

    conn.commit()

    print(f"\nGenerating {n_rows} rows...")

    # customers
    cur.execute(f"""
        INSERT INTO customers(country, age)
        SELECT
            CASE WHEN random() < 0.5 THEN 'US' ELSE 'DE' END,
            (random()*60 + 18)::int
        FROM generate_series(1, {n_rows // 10});
    """)

    # addresses
    cur.execute("""
        INSERT INTO addresses(customer_id, city)
        SELECT id,
               CASE WHEN random() < 0.5 THEN 'Berlin' ELSE 'New York' END
        FROM customers;
    """)

    # categories
    cur.execute("""
        INSERT INTO categories(name)
        VALUES ('electronics'), ('books');
    """)

    # products
    cur.execute(f"""
        INSERT INTO products(category_id, price)
        SELECT (random()*1 + 1)::int, random()*1000
        FROM generate_series(1, {n_rows // 20});
    """)

    # orders
    cur.execute(f"""
        INSERT INTO orders(customer_id, created_at, is_active)
        SELECT
            (random()*({n_rows // 10}-1)+1)::int,
            CURRENT_DATE - (i/50),
            CASE WHEN random() < 0.1 THEN TRUE ELSE FALSE END
        FROM generate_series(1, {n_rows}) i;
    """)

    # order_items (важливо для BRIN — фізично впорядковані)
    cur.execute(f"""
        INSERT INTO order_items(order_id, product_id, value1, value2)
        SELECT
            (i % {n_rows // 20} + 1)::int,
            (i % ({n_rows // 20}) + 1)::int,
            i::int,
            floor(random()*10000)::int
        FROM generate_series(1, {n_rows}) i
        ORDER BY i;
    """)

    conn.commit()

    conn.autocommit = True
    cur.execute("VACUUM ANALYZE;")
    conn.autocommit = False

    print("Done.\n")


#Benchmark
def benchmark(sql):

    # warmup
    for _ in range(WARMUP):
        cur.execute(sql)
        cur.fetchall()

    times = []

    for _ in range(REPEATS):

        t0 = time.perf_counter()

        cur.execute(sql)
        cur.fetchall()

        t1 = time.perf_counter()

        times.append(t1 - t0)

    return statistics.median(times)


#Queries
def measure_select_exact():

    return benchmark("""
        SELECT oi.value1, oi.value2
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.value1 = 500;
    """)


def measure_select_range():

    return benchmark("""
        SELECT *
        FROM order_items
        WHERE value1 BETWEEN 10000 AND 30000;
    """)


def measure_partial_demo():

    return benchmark("""
        SELECT *
        FROM orders
        WHERE is_active = TRUE;
    """)


def measure_brin_demo():

    return benchmark("""
        SELECT *
        FROM order_items
        WHERE value1 BETWEEN 10000 AND 50000;
    """)


def measure_modifications():

    times = []

    for _ in range(REPEATS):

        t0 = time.perf_counter()

        cur.execute(
            "UPDATE order_items SET value2 = value2 + 1 WHERE id < 2000;"
        )

        cur.execute(
            "INSERT INTO order_items(order_id, product_id, value1, value2) VALUES (1,1,1,2);"
        )

        conn.commit()

        t1 = time.perf_counter()

        times.append(t1 - t0)

    return statistics.median(times)


def measure_index_size():

    cur.execute("""
        SELECT pg_relation_size(indexrelid)
        FROM pg_index
        WHERE indrelid IN ('order_items'::regclass, 'orders'::regclass)
        ORDER BY pg_relation_size(indexrelid) DESC
        LIMIT 1;
    """)

    val = cur.fetchone()

    if val is None:
        return 0

    return val[0] / (1024 * 1024)


#Experiments
results_exact = {idx: {} for idx in list(indexes.keys()) + ["no_index"]}
results_range = {idx: {} for idx in list(indexes.keys()) + ["no_index"]}
results_partial = {idx: {} for idx in list(indexes.keys()) + ["no_index"]}
results_brin = {idx: {} for idx in list(indexes.keys()) + ["no_index"]}

for n in SIZES:

    recreate_schema(n)

    base_exact = measure_select_exact()
    base_range = measure_select_range()
    base_partial = measure_partial_demo()
    base_brin = measure_brin_demo()
    base_modify = measure_modifications()

    results_exact["no_index"][n] = {
        "select": base_exact,
        "modify": base_modify,
        "size": 0,
        "build_time": 0,
        "efficiency_gain": 1
    }

    results_range["no_index"][n] = {
        "select": base_range,
        "modify": base_modify,
        "size": 0,
        "build_time": 0,
        "efficiency_gain": 1
    }

    results_partial["no_index"][n] = {"efficiency_gain": 1}
    results_brin["no_index"][n] = {"efficiency_gain": 1}

    for idx_name, idx_sql in indexes.items():

        cur.execute("""
            DROP INDEX IF EXISTS idx_btree;
            DROP INDEX IF EXISTS idx_hash;
            DROP INDEX IF EXISTS idx_composite;
            DROP INDEX IF EXISTS idx_covering;
            DROP INDEX IF EXISTS idx_partial;
            DROP INDEX IF EXISTS idx_brin;
        """)

        conn.commit()

        t0 = time.perf_counter()

        cur.execute(idx_sql)
        conn.commit()

        build_time = time.perf_counter() - t0

        cur.execute("ANALYZE;")

        sel_exact = measure_select_exact()
        sel_range = measure_select_range()
        sel_partial = measure_partial_demo()
        sel_brin = measure_brin_demo()

        mod = measure_modifications()

        size = measure_index_size()

        results_exact[idx_name][n] = {
            "select": sel_exact,
            "modify": mod,
            "size": size,
            "build_time": build_time,
            "efficiency_gain": base_exact / sel_exact
        }

        results_range[idx_name][n] = {
            "select": sel_range,
            "modify": mod,
            "size": size,
            "build_time": build_time,
            "efficiency_gain": base_range / sel_range
        }

        results_partial[idx_name][n] = {
            "efficiency_gain": base_partial / sel_partial
        }

        results_brin[idx_name][n] = {
            "efficiency_gain": base_brin / sel_brin
        }

        print(
            f"{idx_name.upper()} | rows={n} | "
            f"EXACT={base_exact/sel_exact:.2f}x | "
            f"RANGE={base_range/sel_range:.2f}x | "
            f"PARTIAL={base_partial/sel_partial:.2f}x | "
            f"BRIN={base_brin/sel_brin:.2f}x"
        )


#Graphs
def plot_metric(results_dict, metric_name, ylabel, title):

    plt.figure(figsize=(10,6))

    xs = sorted(results_dict["no_index"].keys())
    ys = [results_dict["no_index"][n][metric_name] for n in xs]

    plt.plot(xs, ys, marker="o", linewidth=3, label="no_index")

    for idx_name, data in results_dict.items():

        if idx_name == "no_index":
            continue

        xs = sorted(data.keys())
        ys = [data[n][metric_name] for n in xs]

        plt.plot(xs, ys, marker="o", label=idx_name)

    plt.xlabel("Table size (rows)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True)

    plt.show()


def plot_efficiency(results_dict, title):

    plt.figure(figsize=(10,6))

    for idx_name, data in results_dict.items():

        if idx_name == "no_index":
            continue

        xs = sorted(data.keys())
        ys = [data[n]["efficiency_gain"] for n in xs]

        plt.plot(xs, ys, marker="o", label=idx_name)

    plt.xlabel("Table size (rows)")
    plt.ylabel("Speed-up")
    plt.title(title)
    plt.legend()
    plt.grid(True)

    plt.show()


plot_metric(results_exact, "select", "SELECT time (sec)", "EXACT SELECT performance")
plot_metric(results_range, "select", "SELECT time (sec)", "RANGE SELECT performance")
plot_metric(results_exact, "modify", "UPDATE/INSERT time (sec)", "Modification performance")
plot_metric(results_exact, "size", "Index size (MB)", "Index size")
plot_metric(results_exact, "build_time", "Build time (sec)", "Index build time")

plot_efficiency(results_exact, "EXACT SELECT speed-up")
plot_efficiency(results_range, "RANGE SELECT speed-up")

plot_efficiency(results_partial, "PARTIAL index demo speed-up")
plot_efficiency(results_brin, "BRIN index demo speed-up")

cur.close()
conn.close()

print("\nFinished.")